#!/usr/bin/python

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import sys

'''
Dcoumentation : http://selenium-python.readthedocs.io/getting-started.html
'''


ffpath = "/root/Desktop/training/ch9/chromedriver"
driver = webdriver.Chrome(ffpath)
driver.get("http://www.python.org")
assert "Python" in driver.title
elem = driver.find_element_by_name("q")
elem.clear()
elem.send_keys("pycon")
elem.send_keys(Keys.RETURN)
assert "No results found." not in driver.page_source
driver.close()


'''
ffpath = "/root/Desktop/training/ch9/"
driver = webdriver.Firefox(ffpath)
driver.get("http://www.python.org")
assert "Python" in driver.title
elem = driver.find_element_by_name("q")
elem.clear()
elem.send_keys("pycon")
elem.send_keys(Keys.RETURN)
assert "No results found." not in driver.page_source
driver.close()
'''


