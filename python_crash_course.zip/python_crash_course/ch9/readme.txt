We need browser specific web drivers while working with selenium 

Sites for downloading browser drivers :

geckodriver - firefox
https://github.com/mozilla/geckodriver/releases

chromedriver - chrome
http://chromedriver.chromium.org/downloads
