#!/usr/bin/python

'''
DataStructure 
Ordered datastructure
2. Tuple
Tuple are immutable (cannot be modified) objects in Python
Denote by ()
'''


t = ("python","java",".net","c#")

#exploring tuple items or elements 

print t[0]

nest_t = (("Python","py"),("Java","java"),("VBscript","vbs"),("powershell","ps"))

print nest_t[1]
print "\n"
print nest_t[2]
print "\n"
print nest_t[2][0]
print "\n"
print nest_t[2][1]

#Let's very the object
