#!/usr/bin/python

'''
DataStructure 
Unordered datastructure
3. Dictionary
Dictionary are mutable (can be modified) objects in Python
Denote by {}
They are described as hash pair / Key-pair
As a good practice Only immutable objects can be used as keys
'''

#let's define a empty dictionary

employee = {}

#Lets add some elements 

#------Keys------- ----values--------

employee["Tom"] = "Senior Systems Engineer"
employee["John"] = "Systems Engineer"
employee["Dan"] = "Test Engineer"
employee["Mark"] = "Engineer"

print employee

print '\n'

#Let's very the object

print type(employee)

print '\n'

#Let's modify one of the element

employee["Mark"] = "Manager"

print employee
print '\n'

#The dictionary keys are as follows

employee.keys()

#The dictionary values are as follows

employee.values()

