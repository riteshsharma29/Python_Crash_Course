#!/usr/bin/python

'''
DataStructres in Python
Ordered datastructure
1. list
List are one of most imp and commonly used data strcuctures in Python
List are mutable (can be modified) object and are denoted by []
Denoted by square brackets []
'''



l = ["Python","Java","php","QT","c#",".Net"]


#Let's find the length OR how many elements are stored in our list using Python's inbuilt len function

print "Total elements: " + str(len(l))

'''
we can explore individual elements in the list using indexing method for eg.
Indexing in Python starts with 0 and so ....
'''

print l[0],l[5]

'''
we can also explore elements from the bottom of the list using
-ve indexing
'''

print l[-2],l[-1]


#Let's very the object

print type(l)
