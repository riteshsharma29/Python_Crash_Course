#!/usr/bin/python

'''
DataStructure 
4. string
string are immutable DataStructure in Python
But if we assign a string to variable say x then that variable is mutable
string methods
'''

print "Python is awsome"


#Now let's assign it to a vriable

x = "Python is awsome"
print '\n'
print type(x)

#let's split a string using split method default delimeter / separator is space
myvar = x.split()

print myvar[0]


#Let's try and replace few parts of the string

y = x.replace(" ",'+')

print y


