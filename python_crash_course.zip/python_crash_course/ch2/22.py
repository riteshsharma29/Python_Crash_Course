#!/usr/bin/python

'''
Nested list
'''


l = [["Python","py"],["Bash","sh"],["vbscript","vb"],["Powershell","ps"]]


#Let's find the length OR how many elements are stored in our list using Python's inbuilt len function

print "Total elements: " + str(len(l))

print l[0][1]

print '\n'

print l[2][1]
