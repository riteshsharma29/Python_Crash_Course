#!/usr/bin/python

'''
Slice operator - : can be used to explore 1 or many elements across 
a list
Here : itself plays a important role i order to return elements
'''

l = ["Python","Java","php","QT","c#",".Net","php","Ruby","Bash","Perl"]


# returns first element from begining
print l[:1]
print '\n'

# returns 4 elements from begining
print l[:4]
print '\n'


# returns all starting from wth
print l[4:]
print '\n'

#begin with 1 end with 4th and returns 3
print l[1:4]
print '\n'
