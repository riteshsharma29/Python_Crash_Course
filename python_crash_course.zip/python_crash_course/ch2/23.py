#!/usr/bin/python

'''
list methods
insert
append
remove
pop
del
'''

l = ["Python","Bash","vbscript","Powershell"]


'''insert method takes 2 arguments position index and the item/element to be inserted
Suppose now we want to add a item say between "Bash" and "vbscript"
'''

l.insert(2,"Java")


print l
print '\n'

'''
We can extend list by using append method. It requires only 1 argument/argument (parameter) 
'''

l.append(".net")
l.append("c#")

print l
print '\n'


'''We can delete items from the list using any 1 of these methods.
Let's see it 1-by-1'''

# using python's inbuilt del which requires 1 argument (parameter). del keyword followed by list name and item's index

del l[4]
print l
print '\n'

# using list's remove method which requires item itself to be passed as argument (parameter)

l.remove("Bash")
print l
print '\n'

# pop method requires item's index to passed as argument (parameter) and returns the item

l.pop(2)
print '\n'
print l

