#!/usr/bin/python

'''
DataStructure 
4. set
Mainly used to remove duplicates from a dataStructures
Denoted by keyword set
'''

#let's define a list with few elements

lang = ["python","java",".net","python","java","c#"]

filter_1 = list(set(lang))

print filter_1

employee = ("tom","john","lee","shane","lee","john")

filter_2 = tuple(set(employee))

print '\n'

print filter_2
