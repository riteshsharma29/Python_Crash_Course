#!/usr/bin/python

import sys
import xlrd
import os
import pandas as pd

#open workbook
book = xlrd.open_workbook(os.path.join('source','input.xls'))

'''
#Iterating through the workbook using range func
lastsheet = len(book.sheets())
for sheets in range(0,lastsheet):
    print sheets,book.sheets()[sheets].name
'''

df = pd.DataFrame()

count = 0

#Iterating through the workbook using enumerate func
for sht,sheets in enumerate(book.sheets()):
     print sht,sheets.name
     if sht == 1:
         #last row of a working sheet can be calculated using below method
         lastrow = sheets.nrows
         for row in xrange(3,lastrow):
             lang = sheets.cell(row,1).value
             lang = lang.strip()
             desc = sheets.cell(row,2).value 
             desc = desc.strip()
             #Let's extract only English language labels using Pandas library
             if lang == "English":  
                    count = count + 1   
                    #we specify Language as header for 1st column, Labels as header for 2nd column       
                    data = pd.DataFrame({"Language":lang,"Labels":desc},index=[count])
                    df = df.append(data)


df.to_excel('output.xlsx')
         







