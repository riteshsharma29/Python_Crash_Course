#!/usr/bin/python

'''
file handling
'''

import os
import sys

'''
Basically there are 4 modes
r - read only
w - To write
a - To append new file at the end of the file
r+ - To handle both read & write
'''

'''

myfile = open(os.path.join('data','sample_1.txt'),'r')

for line in myfile:

    line = line.strip('\n')
    
    print line

myfile.close()    

'''

with open(os.path.join('data','sample_1.txt'),'r') as content_file:

     content = content_file.read()

     line = content.split('\n')

     print line[-2] 


