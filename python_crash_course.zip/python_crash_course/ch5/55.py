#!/usr/bin/python
# coding: utf-8 -*-

import codecs
import sys
import os

def find_duplicate(filename):

#empty lists
    unq = []
    dup = []

#read records.txt file 
    filename = codecs.open(filename,encoding='utf-8')

    log_file = codecs.open("log.txt",'w',encoding='utf-8')
    log_file.write("Below values are duplicate" + '\n' + '\n')

#Iterate through the file
    for rec in filename:
        rec = rec.replace('\n',"")
        if rec != "" and rec not in unq:
            unq.append(rec)
        elif rec != "" and rec in unq:
            dup.append(rec)

#log duplicate values
    for vals in dup:        
        log_file.write(vals + '\n')
        print vals

'''Change sample.txt with your file
call find_duplicate function'''

find_duplicate(os.path.join('data',"sample.txt"))
