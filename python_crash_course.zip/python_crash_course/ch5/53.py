#!/usr/bin/python

'''
file handling
'''

import os
import sys
#import codecs

'''
Introduction codecs module
'''

########################################################## Without Codecs  ######################################################################

logfile = open('log_53.txt','w')
outfile = open('out.txt','w')

try:

    myfile = open(os.path.join('data','sample_2.txt'),'r')

    for line in myfile:

         line = line.strip('\n')
   
         outfile.write(line + '\n')

    myfile.close()    

except Exception as e:
      print "\n"
      print e
      logfile.write(str(e))
      print "\n"
