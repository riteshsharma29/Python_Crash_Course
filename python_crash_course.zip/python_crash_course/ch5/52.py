#!/usr/bin/python

'''
file handling with exception handling
'''

import os
import sys

'''
we can learn 2 things from this program
exception handling :
More on below link :
https://docs.python.org/3/tutorial/errors.html
https://docs.python.org/2/tutorial/errors.html
writing file in Python
'''

#Let's Log errors if any
logfile = open('log_52.txt','w')

try:

    myfile = open(os.path.join('data','sample_1.txt'),'r',encoding='utf-8')

    for line in myfile:

         line = line.strip('\n')
    
         print line

    myfile.close()    

except Exception as e:
      print "\n"
      print e
      logfile.write(str(e))
      print "\n"



