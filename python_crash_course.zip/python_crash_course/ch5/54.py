#!/usr/bin/python

'''
file handling
'''

import os
import sys
import codecs

'''
Introduction codecs module
'''

########################################################## With Codecs  ###################################################################### '''

logfile = codecs.open('log_53.txt','w',encoding='utf-8')
outfile = codecs.open('out.txt','w',encoding='utf-8')

try:

    myfile = codecs.open(os.path.join('data','sample_2.txt'),'r',encoding='utf-8')

    for line in myfile:

         line = line.strip('\n')
    
         outfile.write(line + '\n')

    myfile.close()    

except Exception as e:
      print "\n"
      print e
      logfile.write(str(e))
      print "\n"
