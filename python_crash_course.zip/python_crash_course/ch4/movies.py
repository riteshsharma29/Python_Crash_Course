#!/usr/bin/python

'''
Introduction of a simple class
'''

import webbrowser


class Movies():

    #constructor OR init method

    def __init__(self,title,description,trailer):

        self.title = title
        self.description = description
        self.trailer = trailer

#few simple methods are defined below

    def playtrailer(self):

        webbrowser.open(self.trailer)

    def upper(self):

        return self.title.upper()

    def lower(self):

        return self.description.lower()


#let's create an few object of class Movies


movie_1 = Movies("Avatar","From Academy Award winning director James Cameron comes Avatar...","https://www.youtube.com/watch?v=sGRsXdcZeVo")

print movie_1.title
print movie_1.upper() + '\n'
print movie_1.description
print movie_1.lower() + '\n'

movie_1.playtrailer()

movie_2 = Movies("Tarzan","Tarzan Jungle Hero....","https://www.youtube.com/watch?v=PwyGAcSfU4Y")

print movie_2.title
print movie_2.upper() + '\n'
print movie_2.description
print movie_2.lower() + '\n'

movie_2.playtrailer()
