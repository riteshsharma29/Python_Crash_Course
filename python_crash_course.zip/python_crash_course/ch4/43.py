#!/usr/bin/python

'''
Creating a package and importing movies class
'''

from mylib import movies

#few object created same as we did earlier

movie_1 = movies.Movies("Avatar","From Academy Award winning director James Cameron comes Avatar...","https://www.youtube.com/watch?v=sGRsXdcZeVo")

print movie_1.title
print movie_1.upper() + '\n'
print movie_1.description
print movie_1.lower() + '\n'

movie_1.playtrailer()

movie_2 = movies.Movies("Tarzan","Tarzan Jungle Hero....","https://www.youtube.com/watch?v=PwyGAcSfU4Y")

print movie_2.title
print movie_2.upper() + '\n'
print movie_2.description
print movie_2.lower() + '\n'

movie_2.playtrailer()
