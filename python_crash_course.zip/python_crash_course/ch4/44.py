#!/usr/bin/python

'''
Few methods to list down module methods in Python
Using this method will help you to learn module functions and its methods
Always search on Google for further documentation
'''

import os
import PIL
import sys
import numpy
import pandas as pd


print dir(pd)
