#!/usr/bin/python

'''
Introduction of a simple class
'''

import webbrowser


class Movies():

    #constructor OR init method

    def __init__(self,title,description,trailer):

        self.title = title
        self.description = description
        self.trailer = trailer

#few simple methods are defined below

    def playtrailer(self):

        webbrowser.open(self.trailer)

    def upper(self):

        return self.title.upper()

    def lower(self):

        return self.description.lower()
