#!/usr/bin/python

"""
Introduction to modules OR libraries.
Installation of pip is recommended on both Windows & Linux platform for installing useful modules easily
Other method is to install it by downloading the package from PyPi site using this command python setup.py install
we'll walk through both of these methods as we progress 
Let's see how can we import a module (library) & its methods with few examples
"""


'''
we'll import data analysis library called pandas
for convinience we import it as pd using as keyword
'''
import pandas as pd
import numpy as np

'''
In the below code .Series is one of method in pandas module OR library
Similarly .arange is one of method in numpy module OR library

'''

df_1 = pd.Series(np.arange(6))

print df_1

df_2 = pd.DataFrame({"Employee":["Tom","Jerry","John","Jimmy"],"Designation":["Engineer","Systems Engineer","Senior Systems Engineer","Principal Engineer"]})

print df_2

print '\n'

########################################################### Alternate method ######################################

'''
This time we'll import only required methods from both modules
'''
from pandas import Series,DataFrame
from numpy import arange


df_3 = Series(arange(6))

print df_3

df_4 = DataFrame({"Employee":["Tom","Jerry","John","Jimmy"],"Designation":["Engineer","Systems Engineer","Senior Systems Engineer","Principal Engineer"]})

print df_4
