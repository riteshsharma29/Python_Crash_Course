#!/usr/bin/python

'''
enumerate function

Helps in iterating a datasteucture with its position or index
'''

l = ["Cricket","Football","Tennis","Hockey"]

for x,y in enumerate(l):

    print x,y




##############################################################################

'''
 zip function 
It returns a iterator of tuples from 2 Or more list
'''

L1 = ["python","shell","vbscript","pwershell","Perl"]
L2 = [".py",".sh",".vbs",".ps"]

print zip(L1,L2)
