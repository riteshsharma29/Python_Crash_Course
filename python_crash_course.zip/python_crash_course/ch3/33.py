#!/usr/bin/python

'''
iterator
The iterator is a Python object which follows iterator protocol.
It executes 2 methos 1 is iter() and other is next()
'''

x = iter(range(10))

print x.next()
print x.next()
print x.next()
print x.next()
print '\n'


'''
Before getting into concept of
generators let's see how a 
function is defined in Python
'''


def myfunc():

    print "This is a Function"

#calling a function
myfunc()


'''
Refer : www.dataquest.io/blog/python-generators-tutorial
Genrators
Genrators are simply implementation of iterators
Best way to iterate through large datasets for performance enhancement and less memory consumption
'''

def mygen(r):

    yield r


x = mygen(range(5))

print x.next()
