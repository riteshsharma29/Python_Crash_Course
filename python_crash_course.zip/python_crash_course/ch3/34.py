#!/usr/bin/python

'''
for loop
while loop
More example on Generators
List comprehension
'''

#simplest generator example

y = (x*x for x in range(10))

print type(y)
print '\n'

for val in y:
      print val


'''
List comprehensions are very useful again 
Used for iteration,complex mathematical operation,less coding,
excellent in memory managment and performance 
'''

j = [i*i for i in range(20)]

print j
