#!/usr/bin/python

'''
In this chapter we'll focus on some useful builtin functions in Python
range
xrange
enumerate
zip
'''

'''
Range function is returns integer list
It takes maximum 3 parameters 


'''

# range with default parameter as stop
print range(10)
print '\n'

# range with parameter as start,stop
print range(1,15)
print '\n'

# range with parameter as start,stop,step
print range(1,10,2)
print '\n'

##############################################################################################################

'''
xrange returns a xrange object
It takes maximum 3 parameters 
'''


# range with default parameter as stop
print range(10)
print '\n'

# range with parameter as start,stop
print range(1,15)
print '\n'

# range with parameter as start,stop,step
print range(1,10,2)
print '\n'
