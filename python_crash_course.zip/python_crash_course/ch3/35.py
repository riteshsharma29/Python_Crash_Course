#!/usr/bin/python

'''
1.Fabonacii series (Every number is sum of last 2 numbers in the series) : while loop
2.Even/odd/Prime numbers check : for loop
'''

result = []
a,b = 0,1
#loop will run untill the length of the list is less than 10
while len(result) < 10:
    a,b = b,a + b  
    result.append(b)      
print result


def numchk():

    i = input("Enter a number to ckeck if its prime OR odd OR even:")

    if i % 2 == 0 or i == 2: print str(i) + " Number is even number" + '\n'
    if i % 2 > 0: print str(i) + " Number is odd number" + '\n'
    if i == 1 or i == 0:print str(i) + " Number is prime number" + '\n'

    for j in range(2,i+1):
        q = i/j   #quotient
        r = i % j #remainder        
        #if quotient q is >= j and remainder r = 0 will exit for loop and number is not prime
        if q > 1 and r == 0:
            break
        #if quotient q is = j and remainder r = 0 number is prime
        if q == 1 and r == 0: print str(i) + " Number is prime" + '\n'


#call above function
numchk()
    
