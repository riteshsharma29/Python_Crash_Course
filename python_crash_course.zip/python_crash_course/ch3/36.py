#!/usr/bin/python

'''
*args
**kwrags
'''

'''
*args - is used to pass variable number of arguments to a function 
OR
When we are not sure how many number of arguments we are gonna pass to a function
OR
Can be used to pass stored list Or tuples
'''


def squareof(*args):

    for arg in args:
        x = arg * arg
        print x

squareof(2,4,5,8,9)

l = [10,20,30,40]

squareof(*l)

###########################################################################################################

'''
**kwargs - is used when we are not sure how many number of keyword arguments will be 
passed to a function
OR
To pass values of dictionary as keyword arguments
'''

def operation(a = 2,**kwargs):

      for k,v in sorted(kwargs.items()):

          result = v * a

          print '\n' + result

operation(a = 5,l = 5,m = 10,n = 100)
