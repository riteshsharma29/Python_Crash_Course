#!/usr/bin/python
# coding: utf-8 -*-

import pandas as pd
import numpy as np
import os


'''
Documentation : https://pandas.pydata.org/
Also check pandas-cheat-sheet.pdf for details
Pandas is very powerful and efficent Data analysis library in Python
text files, csv's, MS excel,databases,XML,JSON operation becomes easy once we are familiar with Pandas library
'''

# 1-dimensional DataFrame (Series) : has only 1 column

df1 = pd.Series(np.arange(20))

#print df1.shape

# 2-dimensional DataFrame (DataFrame) : > 1 column

df2 = pd.DataFrame({"Languages":["Java","Python","php",".net","c#"],"Source":["Open","Open","Open","License","License"]})

#print df2

print df2
