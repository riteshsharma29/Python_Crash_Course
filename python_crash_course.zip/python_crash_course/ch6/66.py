#!/usr/bin/python
# coding: utf-8 -*-

'''
Pandas json example
'''

import json
from pprint import pprint as pp 
import os
import sys
import pandas as pd

month = []
sales = []


# load json file from /data folder using with handle
with open(os.path.join('datasets','sales.json')) as json_data:
    d = json.load(json_data)

# see what the dictionary looks like
pp (d)

# print the keys and values at the first level
for key, value in d.items():
    print key + ': ', pp(value)

# print the keys and values at the second level
for a in d['contents']:
    for key, value in a.items():
        print key + ': ', value

# print the keys and values at the third level
for a in d['contents']:
    for b in a['monthlySales']:
        for key, value in b.items():
            if key == 'sales':
                sales.append(value)
            elif key == 'month':
                month.append(value)


df =  pd.DataFrame({'month':month,'sales':sales})

print df
