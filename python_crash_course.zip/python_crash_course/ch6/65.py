#!/usr/bin/python
# coding: utf-8 -*-

'''
Pandas json example
'''

import json
from pprint import pprint as pp 
import os
import pandas as pd
from pandas import ExcelWriter
import openpyxl


# load json file from /data folder using with handle
with open(os.path.join('datasets','data.json')) as json_data:
    d = json.load(json_data)

# see what the dictionary looks like
#pp (d)

# print keys,values at the top level
total_keys = len(d.keys())

wb = openpyxl.Workbook()
wb.save('json.xlsx')
book = openpyxl.load_workbook('json.xlsx')
writer = ExcelWriter('json.xlsx', engine='openpyxl') 

for x in range(0,total_keys):
    
    df = pd.DataFrame({d.keys()[x]:d.values()[x]})

    df.to_excel(writer,sheet_name=str(d.keys()[x]))
    
    writer.save()
