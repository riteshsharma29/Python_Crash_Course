#!/usr/bin/python
# coding: utf-8 -*-

import pandas as pd
import os
import sys

'''
Concept of passing arguments to a Python script
Reading MS excel file using pandas
Would recommend to visit below websites to explore power of Python and Pandas:
http://pbpython.com/
'''

scriptname = sys.argv[0]
scriptname = scriptname.replace("./","")

print scriptname
print '\n'

if len(sys.argv) < 2:
    print '\n'
    print "Required parameters not passed with the script"
    print "Required parameters : excel filename as 1st parameter, excel sheetname 2nd parameter"
    print "example usage : ./62.py sample.xls common"
    print '\n'
    sys.exit()


filename = sys.argv[1]
sheetname = sys.argv[2]

df = pd.read_excel(os.path.join('datasets',filename),sheetname=sheetname,header=2)

colnames = df.columns

print df.shape
print '\n'

print colnames
print '\n'

nofrows = df.shape[0]
nofcol = df.shape[1]

print nofrows
print nofcol
print '\n'

#serach examples :

# below returns total number of rows cotaining string 'English'
print len(df[df['Languages'] == 'English'])

# below returns rows numbers containing string 'English'
print df.index[df.Languages == 'English']

