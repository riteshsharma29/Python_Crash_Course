#!/usr/bin/python
# coding: utf-8 -*-

'''
Pandas html example
USEFUL TOOL : Python webtable extractor
'''

import pandas as pd
from pandas import ExcelWriter
import openpyxl
import sys
import config6


#read URL name from the config.py file
mylink = config6.Linkname

try:
	df = pd.read_html(mylink)

except:
        print '\n'
	print "Could not open the link. Something went wrong !!!. Please check the link passed in the config6.py Please make sure webpage has html Tables to extract !!!" + '\n' + '\n'
        print '\n'
	sys.exit()


def pd_html_excel():

        wb = openpyxl.Workbook()
        wb.save('tables.xlsx')
	book = openpyxl.load_workbook('tables.xlsx')
	writer = ExcelWriter('tables.xlsx', engine='openpyxl') 	

	for x in range(0,len(df)):

		df[x].to_excel(writer,sheet_name="table_" + str(x))
	
	writer.save()

pd_html_excel()
