#!/usr/bin/python

from selenium import webdriver
from selenium.webdriver.support import ui
from selenium.webdriver.common.keys import Keys
import time
import pandas as pd
import openpyxl
from openpyxl import load_workbook
from openpyxl import __version__
from pandas import ExcelWriter
import sys

'''
Datepicker selection code links :

Found solution from this : https://www.edureka.co/community/6369/not-able-call-onclick-datepicker-function-python-selenium
https://stackoverflow.com/questions/21398575/select-a-date-from-date-picker-using-selenium-webdriver
https://stackoverflow.com/questions/36723659/python-selenium-datepicker-click
https://stackoverflow.com/questions/39520708/using-selenium-on-calendar-date-picker
'''

#This below code will help to append output in same workbook

wb = openpyxl.Workbook()
wb.save('menu_Listing.xlsx')
book = load_workbook('menu_Listing.xlsx')
writer = ExcelWriter('menu_Listing.xlsx', engine='openpyxl') 	
writer.book = book
writer.sheets = dict((ws.title, ws) for ws in book.worksheets) 


#Dynamic function with 3 param category no.,Date,destination city

def menulist(catno,datestring,destination):

    l = []

    mylink = 'http://staging.airnewzealandife.com/november-2017/all/movies/' + str(catno)

    driver=webdriver.Firefox(executable_path=r'/root/Desktop/python_course_materials/ch11/geckodriver')
    driver.get(mylink)
    wait = ui.WebDriverWait(driver,10)
    #Uncomment below if you want to maximize browser window
    #driver.maximize_window()
    #driver.implicitly_wait(20)   

    #selecting Date
    datefield = driver.find_element_by_id('datepicker')
    driver.execute_script("arguments[0].removeAttribute('readonly')", datefield)
    datefield.send_keys(datestring)

    # selecting destination
    dest_field = driver.find_element_by_name("destination")
    # <option "Public PC </option>, <option "Scanner PC </option>
    for opt in dest_field.find_elements_by_tag_name('option'):
    #print opt.text
        if opt.text == destination:
            opt.click()
            break

   #wait for 5 sec
    time.sleep(5)
    driver.find_element_by_xpath("//input[@value='Go']").click()
    time.sleep(5)

    #iterate through listing page
    results = driver.find_elements_by_xpath('//*[@id="listing"]')
    for result in results:
        #splitting result var by '|Or' separator
        r = result.text.replace('\n','|').split('|Or')
        l.append(r[0])

    #empty list
    title = []
    dur = []
    for x in l[0].split('.|'):
        title.append(x.split("|")[0].encode('utf-8'))
        dur.append(x.split("|")[1])

    df = pd.DataFrame({"Menu title":title,"Duration":dur})
    df.to_excel(writer,sheet_name=str(catno),index=True)    
    writer.save()
    driver.quit()


#Calling aobove function with some date and destination

menulist(20070335,'14 September 2018','Cairns (CNS)')
menulist(20070332,'08 September 2018','Brisbane (BNE)')
