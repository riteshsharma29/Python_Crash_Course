#!/usr/bin/python

mylink = "http://www.globaleagle.com/"
mytext = "Get started with Django"
