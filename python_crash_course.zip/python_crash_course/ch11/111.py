#!/usr/bin/python

from selenium import webdriver
from selenium.webdriver.common.keys import Keys
import sys
import unittest
from configs import config11

'''
This script will test click functionality of a webpage by passing web url and text element
web url and text element need to be passed in config11.py file
https://stackoverflow.com/questions/37879010/selenium-debugging-element-is-not-clickable-at-point-x-y
'''

mylink = config11.mylink
mytext = config11.mytext


class PythonOrgSearch(unittest.TestCase):

    def setUp(self): 
          self.driver = webdriver.Chrome(executable_path=r'/root/Desktop/python_course_materials/ch11/chromedriver')


    def test_search_url_links(self):

        driver = self.driver
        driver.set_window_size(1024, 600)
        driver.maximize_window()
        driver.get(mylink)
        driver.implicitly_wait(10)
        clicktest = driver.find_element_by_partial_link_text(mytext)
        clicktest.click()

    def tearDown(self): 
        self.driver.save_screenshot('href_screenshot.png')
        self.driver.close()

if __name__ == "__main__":
    unittest.main()
