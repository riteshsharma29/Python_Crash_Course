#!/usr/bin/python

from selenium import webdriver
import sys
import codecs
import requests
from configs import config11

'''
Refer this link for internal/external links theory :http://www.corelangs.com/html/links/internal-links.html

This script generates log file for internal and external links repsectively
'''

mylink = config11.mylink
file_1 = codecs.open("int_link.txt",'w',encoding='utf-8')
file_2 = codecs.open("ext_links.txt",'w',encoding='utf-8')

mlnk = mylink.split('.')
if len(mlnk) >= 2:
    domain = mlnk[1] + "." + mlnk[2] 
else:
    domain = mlnk[1] + "." 
domain = domain.replace('/',"")


options = webdriver.ChromeOptions() 
options.add_argument("start-maximized")
options.add_argument('disable-infobars')
driver=webdriver.Chrome(chrome_options=options, executable_path=r'/root/Desktop/python_course_materials/ch11/chromedriver')
driver.get(mylink)

mylinks = []
elems = driver.find_elements_by_xpath("//a[@href]")
for elem in elems:
    if not elem.get_attribute("href") in mylinks:
        mylinks.append(elem.get_attribute("href"))
        if "https://" in elem.get_attribute('href') or "http://" in elem.get_attribute('href'):
            r = requests.head(elem.get_attribute('href'))
            genstr = str(elem.get_attribute('href')) + ":" + str(r.status_code) + '\n'
            if domain in elem.get_attribute('href'):            
                file_1.write(genstr)
            if not domain in elem.get_attribute('href'):         
                file_2.write(genstr)

