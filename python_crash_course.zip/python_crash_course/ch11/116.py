#!/usr/bin/python

from selenium import webdriver
from selenium.webdriver.support import ui
from selenium.webdriver.common.keys import Keys
import codecs

'''
This is again partial example of form filling using selenium. This website has some issues though.
'''


#The below parameters / arguments remains unchanged hence we will only pass 2nd argument ie. lnktext 
srclnk = 'http://newtours.demoaut.com/mercurywelcome.php'
xpath_var = "//a[@href='mercurywelcome.php']"

#log file for test result:
logfile = codecs.open("log.txt",'a+',encoding='utf-8')



def mylink(srclnk,lnktext):

    driver=webdriver.Firefox(executable_path=r'/root/Desktop/python_course_materials/ch11/geckodriver')   
    #driver=webdriver.Chrome(executable_path=r'/root/Desktop/python_course_materials/ch11/chromedriver')

    try:

        driver.get(srclnk)

        driver.find_element_by_partial_link_text(lnktext).click()
        driver.maximize_window()
        driver.implicitly_wait(20)   

#Filling up the registration form

        fname = driver.find_element_by_name("firstName")
        fname.send_keys('James')

        lname = driver.find_element_by_name("lastName")
        lname.send_keys('Bond')

        phone = driver.find_element_by_name("phone")
        phone.send_keys('777')

        eml = driver.find_element_by_name("userName")
        eml.send_keys('jamesbond@gmail.com')

        '''addr = driver.find_element_by_name("address1")
        aadr.send_keys('302 North Street')

        add_2 = driver.find_element_by_name("address2")
        add_2.send_keys('Park Avenue Town')'''

        city = driver.find_element_by_name("city")
        city.send_keys('New York')

        city = driver.find_element_by_name("state")
        city.send_keys('Texas')

        pcode = driver.find_element_by_name("postalCode")
        pcode.send_keys('400060')

        time_hr = driver.find_element_by_name("country")
        for cont in time_hr.find_elements_by_tag_name('option'):
            if cont.text == 'UKRAINE':
                cont.click()        

    except Exception as e:
        print e



mylink(srclnk,'REGISTER')
