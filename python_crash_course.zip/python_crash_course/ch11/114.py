#!/usr/bin/python

from selenium import webdriver
from selenium.webdriver.support import ui
from selenium.webdriver.common.keys import Keys
'''
source link : https://www.youtube.com/watch?v=OPXnIznhvVc
Nice Documentaion on locating elements : https://www.guru99.com/locators-in-selenium-ide.html
https://stackoverflow.com/questions/37879010/selenium-debugging-element-is-not-clickable-at-point-x-y
This script shows example of filing up form details for PC reservation
'''

mylink = 'https://pcres.cincinnatilibrary.org/scripts/pcres/reserve.pl'

driver=webdriver.Firefox(executable_path=r'/root/Desktop/python_course_materials/ch11/geckodriver')
driver.get(mylink)
wait = ui.WebDriverWait(driver,10)

#selecting the item from the dropdown box

locate_field = driver.find_element_by_name("branch")
for option in locate_field.find_elements_by_tag_name('option'):
    if option.text == 'Blue Ash':
        option.click()
        break

#selecting submit button
driver.implicitly_wait(10)
driver.find_element_by_xpath("//input[1]").click()
driver.implicitly_wait(10)


#Filling registration details

# <input type="text" name="user_id" size="25">
card_no = driver.find_element_by_name("user_id")
card_no.send_keys('xxxxxxxxx')

# <input type="password" name="pin" size="15">
pin_code = driver.find_element_by_name("pin")
pin_code.send_keys('400060')


# selecting area option after parsing / iterating through the dropdown menu
# <select name=area">
area_field = driver.find_element_by_name("area")
# <option "Public PC </option>, <option "Scanner PC </option>
for opt in area_field.find_elements_by_tag_name('option'):
    #print opt.text
    if opt.text == 'Scanner PC':
        opt.click()
        break

# we can detect Date similarly as we found area
day_field = driver.find_element_by_name("day")
for opt_2 in day_field.find_elements_by_tag_name('option'):
    #print opt_2.text
    if opt_2.text == 'Tomorrow':
        opt_2.click()
        break

#similarly hour
time_hr = driver.find_element_by_name("hour")
for opt_3 in time_hr.find_elements_by_tag_name('option'):
    if opt_3.text == '02':
        opt_3.click()
        break

#similarly minute
time_min = driver.find_element_by_name("minute")
for opt_4 in time_min.find_elements_by_tag_name('option'):
    if opt_4.text == '15':
        opt_4.click()
        break

# select am/pm using find_element_by_xpath method
driver.find_element_by_xpath("//input[@value='pm']").click()


# select am/pm using find_element_by_xpath method
driver.find_element_by_xpath("//input[@value='Submit']").click()


reserve_fail = driver.find_element_by_xpath("//center[contains(text(),'The reservation could not be made')]")

# if the reservation fails we redirect to the home page
if reserve_fail.text == 'The reservation could not be made. (The Library Card Number is invalid.)':
    x = driver.find_element_by_xpath("//a[@href='/scripts/pcres/reserve.pl']")
    #If another element is covering the element you are to click. You could use execute_script() to click on this.
    driver.execute_script("arguments[0].click();", x)


