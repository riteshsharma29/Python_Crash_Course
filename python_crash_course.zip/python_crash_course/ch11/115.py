#!/usr/bin/python

from selenium import webdriver
from selenium.webdriver.support import ui
from selenium.webdriver.common.keys import Keys
import codecs

'''
This a simple script which tests different tabs of the website based on link text a Python function
https://www.techbeamers.com/websites-to-practice-selenium-webdriver-online/
'''


#The below parameters / arguments remains unchanged hence we will only pass 2nd argument ie. lnktext 
srclnk = 'http://newtours.demoaut.com/mercurywelcome.php'
xpath_var = "//a[@href='mercurywelcome.php']"

#log file for test result:
logfile = codecs.open("log.txt",'a+',encoding='utf-8')

def mylink(srclnk,lnktext,xpath_var):

    driver=webdriver.Firefox(executable_path=r'/root/Desktop/python_course_materials/ch11/geckodriver')   
    #driver=webdriver.Chrome(executable_path=r'/root/Desktop/python_course_materials/ch11/chromedriver')

    try:

        driver.get(srclnk)

        driver.find_element_by_partial_link_text(lnktext).click()
        driver.maximize_window()
        driver.implicitly_wait(20)   
        x = driver.find_element_by_xpath(xpath_var)
        #If another element is covering the element you are to click. You could use execute_script() to click on this.
        driver.execute_script("arguments[0].click();", x)
        driver.close()
        logfile.write("Test case for :" + lnktext + " passed" + '\n')

    except Exception as e:
        #print e
        logfile.write(str(e) + '\n')


mylink(srclnk,'CONTACT',xpath_var)
mylink(srclnk,'SUPPORT',xpath_var)
'''
mylink(srclnk,'Hotels',xpath_var)
mylink(srclnk,'Cruises',xpath_var)
'''
