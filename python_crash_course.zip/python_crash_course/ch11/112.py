#!/usr/bin/python

from selenium import webdriver
import sys
import codecs
import requests
from configs import config11

'''
prequisite for ubuntu 12.04
apt-get purge python-openssl
pip install pyopenssl

This script will test valid and broken links of a webpage and will generate log file accordingly
web url need to be passed in config11.py file
'''

mylink = config11.mylink
file_1 = codecs.open("stat_ok.txt",'w',encoding='utf-8')
file_2 = codecs.open("stat_not_ok.txt",'w',encoding='utf-8')

options = webdriver.ChromeOptions() 
options.add_argument("start-maximized")
options.add_argument('disable-infobars')
driver=webdriver.Chrome(chrome_options=options, executable_path=r'/root/Desktop/python_course_materials/ch11/chromedriver')
driver.get(mylink)

mylinks = []
elems = driver.find_elements_by_xpath("//a[@href]")
for elem in elems:
    if not elem.get_attribute("href") in mylinks:
        mylinks.append(elem.get_attribute("href"))
        if "https://" in elem.get_attribute('href') or "http://" in elem.get_attribute('href'):
            r = requests.head(elem.get_attribute('href'))
            genstr = str(elem.get_attribute('href')) + ":" + str(r.status_code) + '\n'
            if r.status_code == 200:            
                file_1.write(genstr)
            if r.status_code != 200:         
                file_2.write(genstr)
