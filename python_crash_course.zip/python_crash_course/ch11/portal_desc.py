#!/usr/bin/python

from selenium import webdriver
from selenium.webdriver.support import ui
from selenium.webdriver.common.keys import Keys
import time
import pandas as pd
import openpyxl
from openpyxl import load_workbook
from openpyxl import __version__
from pandas import ExcelWriter
import sys
import codecs
import os


'''
Run this script portal_menu_img.py before running this script
This script downloads sysnopsis info from the webpage
'''

mypath = os.getcwd()
fpath = os.path.join(mypath,"desc_link.txt")

if not os.path.exists(fpath):
    print "\n"
    print "\n"
    print "ERROR !!! desc_link.txt Missing !!! Run & execute portal_menu_img.py script before running this script"
    print "\n"
    print "\n"
    sys.exit()

#This below code will help to append output in same workbook

wb = openpyxl.Workbook()
wb.save('description.xlsx')
book = load_workbook('description.xlsx')
writer = ExcelWriter('description.xlsx', engine='openpyxl') 	
writer.book = book
writer.sheets = dict((ws.title, ws) for ws in book.worksheets) 

#Let's open the browser only once
driver=webdriver.Firefox(executable_path=r'/root/Desktop/python_course_materials/ch11/geckodriver')

#open the log file consisting description page links
desclog = codecs.open("desc_link.txt",encoding='utf-8')

#creating empty lists to store respective movie details

title = []
dur = []
desc = []
dirc = []
cast = []
rat = []
gen = []

for mylink in desclog:

    mylink = mylink.strip('\n')
  

    #we don't require tv data hence we'll exit for loop
    if "tv" in mylink:
        break
    
    driver.get(mylink)
    wait = ui.WebDriverWait(driver,10)
    #Uncomment below if you want to maximize browser window
    #driver.maximize_window()
    #driver.implicitly_wait(20)   

    #read description page
    results = driver.find_elements_by_xpath('//*[@id="synopsis"]/section')

    for result in results:
        x = result.text.split('\n')

        #to avoid out of index error
        try:
            title.append(x[0])
            dur.append(x[1])
            desc.append(x[2])
            dirc.append(x[3])
            cast.append(x[4])
            rat.append(x[5])
            gen.append(x[6])    
        except IndexError:
            pass
        continue            

    df = pd.DataFrame({"Description title":title,"Duration":dur,"description":desc,"Director":dirc,"Cast":cast,"Rating":rat,"Genre":gen})
    df.to_excel(writer,sheet_name="Description",index=True)    
    writer.save()

driver.quit()
