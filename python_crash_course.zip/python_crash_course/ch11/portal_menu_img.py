#!/usr/bin/python

from selenium import webdriver
from selenium.webdriver.support import ui
from selenium.webdriver.common.keys import Keys
import time
import sys
import os
import codecs
import urllib

'''
This script downloads menu images and generates synopsis page link
'''

desc = codecs.open("desc_link.txt",'w',encoding='utf-8')
imges = codecs.open("img_link.txt",'w',encoding='utf-8')

#Let's create images directory

os.system('mkdir images')
os.system('chmod -R 777 images')


#Dynamic function with 3 param category no.,Date,destination city

def menulist(catno,datestring,destination):

    l = []

    mylink = 'http://staging.airnewzealandife.com/november-2017/all/movies/' + str(catno)

    driver=webdriver.Firefox(executable_path=r'/root/Desktop/python_course_materials/ch11/geckodriver')
    driver.get(mylink)
    wait = ui.WebDriverWait(driver,10)
    #Uncomment below if you want to maximize browser window
    #driver.maximize_window()
    #driver.implicitly_wait(20)   

    #selecting Date
    datefield = driver.find_element_by_id('datepicker')
    driver.execute_script("arguments[0].removeAttribute('readonly')", datefield)
    datefield.send_keys(datestring)

    # selecting destination
    dest_field = driver.find_element_by_name("destination")
    # <option "Public PC </option>, <option "Scanner PC </option>
    for opt in dest_field.find_elements_by_tag_name('option'):
    #print opt.text
        if opt.text == destination:
            opt.click()
            break

   #wait for 5 sec
    time.sleep(5)
    driver.find_element_by_xpath("//input[@value='Go']").click()
    time.sleep(5)

    #iterate through listing page to pull description link
    desclnk = driver.find_elements_by_xpath('//*[@class="listing-item"]/a[@href]')    
    for d in desclnk:
        #print d.get_attribute("href")
        desc.write(d.get_attribute("href") + '\n')
    images = driver.find_elements_by_xpath('//*[@class="listing-item"]/a[@href]/img[@src]')    
    c = 1
    for i in images:
        url = i.get_attribute("data-original")
        print urllib.unquote(url).decode('utf8')
        urllib.urlretrieve(url,'images/' + str(c) + ".jpg")
        c += 1
        imges.write(i.get_attribute("data-original") + '\n')
    driver.quit()

#Calling aobove function with some date and destination

menulist(20070335,'14 August 2018','Cairns (CNS)')
#menulist(20070332,'08 August 2018','Brisbane (BNE)')
