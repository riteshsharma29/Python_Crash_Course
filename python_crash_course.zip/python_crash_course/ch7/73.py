#!/usr/bin/python
# coding: utf-8 -*-

import xml.etree.ElementTree as ET
# Documentation : https://docs.python.org/2/library/xml.etree.elementtree.html

import pandas as pd
import os
import sys

'''
Tag - starts with < ends with >
attribute - Is with = sign
Text OR data is between - <>
'''

tree = ET.parse(os.path.join('xml','msdn.xml'))
root = tree.getroot()


for c in root:
    print c.tag, c.attrib

#creating empty list for DataFrame creation

auth = []
tit = []
gen = []
prc = []
pdate = []
desc = []


for child in root.iter('book'):
    for a in child.findall('author'):
        auth.append(a.text)
    for t in child.findall('title'):
        tit.append(t.text)
    for g in child.findall('genre'):
        gen.append(g.text)
    for p in child.findall('price'):
        prc.append(p.text)
    for p_d in child.findall('publish_date'):
        pdate.append(p_d.text)
    for d in child.findall('description'):
        desc.append(d.text)


df = pd.DataFrame({'Author':auth,'Title':tit,'Genre':gen,'Price':prc,'PublishDate':pdate,'Description':desc})

df.to_excel('msdn.xlsx')

df.to_csv('msdn.csv')

