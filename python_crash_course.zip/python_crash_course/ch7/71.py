#!/usr/bin/python
# coding: utf-8 -*-

import xml.etree.ElementTree as ET
# Documentation : https://docs.python.org/2/library/xml.etree.elementtree.html

import pandas as pd
import os


'''
Tag - starts with < ends with >
attribute - Is with = sign
Text OR data is between - <>
'''


tree = ET.parse(os.path.join('xml','donuts.xml'))
root = tree.getroot()

L1 = []
L2 = []
L3 = []

b1 = []
b2 = []
b3 = []


for c in root:
    print c.tag, c.attrib

for child in root.iter('item'):
        for name in child.findall('name'):
            #print name.text
            L1.append(name.text)
        for ppu in child.findall('ppu'):
            #print ppu.text
            L2.append(ppu.text)
        for topping in child.findall('topping'):
            #print topping.text
            L3.append(topping.text)

def dataset(label,List):

     df = pd.DataFrame({label:L1})

     print df

#dataset("tag",L1)
#dataset("tag",L2)
dataset("tag",L3)

for b in root.iter('batters'):
    for batter in b.findall('batter'):
        #print batter.tag,batter.attrib,batter.text
        b1.append(batter.tag)
        b2.append(batter.attrib)
        b3.append(batter.text)

df_2 = pd.DataFrame({"name":b1,"Attribute":b2,"Text":b3})

print df_2












