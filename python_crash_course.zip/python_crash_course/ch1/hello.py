#!/usr/bin/python

#To startwith very familiar hello world program

"""
Similar to other programing languages we can write comments in 2 ways
Single line comment cab written followed by # 
Mutiline comment can be written between 3 single OR 3 Double quotes
"""


#print function below works well only in Python version 2.7 

print '\n'
print '\n'
print "hello guys ! welcome to Python training"
print '\n'
print '\n'

#print function below works well both in Python version 2.7 and 3.5

print ('\n')
print ('\n')
print ("hello A warm welcome")
print '\n'
print '\n'
