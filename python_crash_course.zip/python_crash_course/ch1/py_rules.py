#!/usr/bin/python


#Check out Python styling guide pep8 on python.org for more details
#Check out Errors and Exceptions on python.org for more details

'''
Python is case sensitive language
Python code blocks have to be strictly indented with 4 spaces Note : Tabs not recommended
If indenations are not followed indentaion exception will be raised
Concatenation of string and integers have to be prehandled. 
Everything in Python is an object.
'''



for i in range(10):
    print i 
    if i > 5:
        print str(i) + "is greater than"
print type(i)        
