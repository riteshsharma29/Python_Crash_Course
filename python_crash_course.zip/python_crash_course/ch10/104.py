#! /usr/bin/env python
# -*- coding: utf-8 -*-

import pandas as pd
import pdsql
import sys

mysqldb = pdsql.PandasMysql()

df = pd.read_csv('titanic_data.csv')


#the below method will create and load dataframe in the table

mysqldb.df_to_new_mysql("localhost","root","woiseepz",21,"test","Titanic",df)

#the below method will load dataframe in the existing table

mysqldb.df_to_exist_mysql("localhost","root","woiseepz",21,"test","Titanic",df)

#the below method will export dataframe to CSV

mysqldb.export_df("localhost","root","woiseepz",21,"test","Titanic","export.csv")
