#!/usr/bin/python

import pandas as pd
from pandas import ExcelWriter
import os
import openpyxl
from openpyxl import load_workbook
import sqlite3

	
con = sqlite3.connect(os.path.join('db/backup/','sample.db'))
cursor = con.cursor()
cursor.execute("SELECT name from sqlite_master WHERE type ='table';")
tblviews = (cursor.fetchall())
#print type(tblviews)

#create a excel workbook
wb = openpyxl.Workbook()
wb.save('tables.xlsx')

def pandas_dbexcel(viewname,con):

	book = openpyxl.load_workbook('tables.xlsx')
	writer = ExcelWriter('tables.xlsx', engine='openpyxl')
	df = pd.read_sql_query("SELECT * from " + viewname, con)
	writer.book = book
	writer.sheets = dict((ws.title, ws) for ws in book.worksheets)

	#verify that result of SQL query is stored in the dataframe
	#print(df)

	df.to_excel(writer,sheet_name=viewname)

	writer.save()

for tblvno,tblview in enumerate(tblviews):

	viewname = str(tblview).replace("(u'","").replace("',)","")

	pandas_dbexcel(viewname,con)
	
if __name__ == "__main__":
	os.system('echo Database views / tables exported into export xlsx file found based on the second parameter passed>> log.txt')

		
