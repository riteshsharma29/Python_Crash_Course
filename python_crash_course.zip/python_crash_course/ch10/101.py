#!/usr/bin/python

'''
pip install pysqlite
Reading records SQlite3 DB
Deleting records SQlite3 DB
Updating records SQlite3 DB
inserting records SQlite3 DB
'''

import sqlite3
import os



con = sqlite3.connect(os.path.join('db','sample.db'))
cursor = con.cursor()
cursor.execute("SELECT name from sqlite_master WHERE type ='table';")
tblviews = (cursor.fetchall())
print tblviews
tblist = str(tblviews).strip('[]').replace("(","").replace(",)","").replace("u","").replace("'","").replace(" ","")

#Below are different ways to iterate and list all the tables in the database
'''
for table in tblist.split(","):
    print table
'''

'''
t = [table for table in tblist.split(",")]
for tb in range(0,len(t)):
    print t[tb]
'''

query_1 = cursor.execute("SELECT * from 'videoDescriptionTable' where `cast`= 'n/a';")
res_1 = (cursor.fetchall())
print res_1[-1]

query_2 = cursor.execute("Delete from 'videoDescriptionTable' where `cast`= 'n/a';")
con.commit

query_3 = cursor.execute("UPDATE 'categoryInfoTable' SET `title` = 'Gaming' WHERE `title`='Games';")
con.commit()

query_4 = cursor.execute("INSERT INTO `ccSubtitlesTable` (LID, MID,PID, ccSubtitleDef,languageOrder) VALUES (1,4000,0,'embedded',0);")
con.commit()

con.close()
