#! /usr/bin/env python
# -*- coding: utf-8 -*-

'''
Prequesite commands :

pip install mysqlclient
pip install mysql-python

'''

import MySQLdb

#Open database connection

conn = MySQLdb.connect(host = 'localhost',port = 21,user='root',passwd = 'woiseepz',db = 'test')

# prepare a cursor object using cursor() method
cursor = conn.cursor()

# create query
sql_1 = """CREATE TABLE `Titanic` (
  `PassengerId` bigint(20) DEFAULT NULL,
  `Survived` bigint(20) DEFAULT NULL,
  `Pclass` bigint(20) DEFAULT NULL,
  `Name` text CHARACTER SET latin1,
  `Sex` text CHARACTER SET latin1,
  `Age` double DEFAULT NULL,
  `SibSp` bigint(20) DEFAULT NULL,
  `Parch` bigint(20) DEFAULT NULL,
  `Ticket` text CHARACTER SET latin1,
  `Fare` double DEFAULT NULL,
  `Cabin` text CHARACTER SET latin1,
  `Embarked` text CHARACTER SET latin1
) ;"""

cursor.execute(sql_1)

sql_2 = """INSERT INTO `Titanic` (`PassengerId`, `Survived`, `Pclass`, `Name`, `Sex`, `Age`, `SibSp`, `Parch`, `Ticket`, `Fare`, `Cabin`, `Embarked`) VALUES ('0', '1', '0', 'Betany, Mrs. Owen Harris', 'Female', '22', '0', '1', '0', '18556', 'c85', 'S')"""

cursor.execute(sql_2)
conn.commit()


# Delete query
cursor.execute("DROP TABLE IF EXISTS Titanic")
conn.commit()

# create a query
conn.close()


